import numpy as np
import matplotlib.pyplot as plt
import os
import pandas as pd
 
#working units: E=ksi, A= in^2, Load= Kips
#modified over: https://www.youtube.com/watch?v=Y-ILnLMZYMw

#%% Truss iproperties input
E=float(input("Enter value of E in ksi: "))
A=float(input("Enter value of A in in^2: "))
#E=30e4 #lb/in^2
#A=0.111 #in^2

path=os.getcwd()
data=pd.read_csv(path+'\\2D.csv')
NODES=data.Nodes.dropna()
X=data.x.dropna()
Y=data.y.dropna()

N_i=data.node_i.dropna()
N_j=data.node_j.dropna()
loadX=data.load_x.dropna()
loadY=data.load_y.dropna()
dofX=data.dof_x.dropna()
dofY=data.dof_y.dropna()


l=len(NODES)
elem=len(N_i)
nodes=[]    #defining matrix of nodes
bars=[]     #defining matrix for elements
P=[]        #defining matrix for loads
con_dof=[]   #defining matrix for DOF

for i in range(l):
    nodes.append([X.iloc[i],Y.iloc[i]]) #Reading node geometry from csv file
for i in range(elem):
    bars.append([N_i.iloc[i],N_j.iloc[i]])  #Reading element geometry from excel file
for i in range(l):
    P.append([loadX.iloc[i],loadY.iloc[i]]) #Reading load value from csv file
for i in range(l):
    con_dof.append([dofX.iloc[i],dofY.iloc[i]]) #Reading degree of freedoms from csv file

nodes=np.array(nodes) #converting list to ndarray
bars=np.array(bars) #converting list values to ndarray
P=np.array(P)
con_dof=np.array(con_dof)


sup=len(dofX)+len(dofY)-np.count_nonzero(dofX)-np.count_nonzero(dofY) 
    #counting numbers of dof where movement is not possible

Ur=[0]*sup #making displacement matrix where movement is not possible

#%% Truss analysis
def TrussAnalysis():
    node_num=len(nodes) #number of nodes
    bar_num=len(bars) #number of elements
    DOF=2
    dof_num= DOF*node_num #Total numbers of DOF = 2* number of nodes for 2D truss
    
    #Truss analysis
    d=nodes[bars[:,1],:]-nodes[bars[:,0],:] #creating matrix of [(xj-xi) (yj-yi)] for each bars
    L=np.sqrt((d**2).sum(axis=1))
    theta=d.T/L
    a=np.concatenate((-theta.T,theta.T),axis=1)
    K=np.zeros([dof_num,dof_num])
    for k in range(bar_num):
        aux=2*bars[k,:]
        index=np.r_[aux[0]:aux[0]+2,aux[1]:aux[1]+2]
        K_loc=np.dot(a[k][np.newaxis].T*E*A,a[k][np.newaxis])/L[k] #local stiffness matrix
        K[np.ix_(index,index)]=K[np.ix_(index,index)]+K_loc
        
    DOF_free=con_dof.flatten().nonzero()[0] #Eleminating DOF at support
    DOF_support=(con_dof.flatten()==0).nonzero()[0]
    Kff=K[np.ix_(DOF_free,DOF_free)]
    Kfr=K[np.ix_(DOF_free,DOF_support)]
    Krf=Kfr.T
    Krr=K[np.ix_(DOF_support,DOF_support)]
    Pf=P.flatten()[DOF_free]
    Uf=np.linalg.solve(Kff,Pf)
    U=con_dof.astype(float).flatten()
    U[DOF_free]=Uf
    U[DOF_support]=Ur
    U=U.reshape(node_num,DOF)
    u=np.concatenate ((U[bars[:,0]],U[bars[:,1]]),axis=1)
    ax=E*A/L[:]*(a[:]*u[:]).sum(axis=1)
    Rxn=(Krf[:]*Uf).sum(axis=1)+(Krr[:]*Ur).sum(axis=1)
    Rxn=Rxn.reshape(int(sup/2),DOF)
    return np.array(ax), np.array(Rxn), U

#%%Plot
def Plot(nodes,c,lt,lw,lg):
    for i in range(len(bars)):
        xi, xf = nodes[bars[i,0],0],nodes[bars[i,1],0]
        yi, yf = nodes[bars[i,0],1],nodes[bars[i,1],1]
        line, = plt.plot([xi,xf],[yi,yf],color=c,linestyle=lt,lw=lw)
    line.set_label(lg)
    plt.legend(prop={'size':8})


#%% Result
ax, Rxn, U = TrussAnalysis() 
print('_______________________________________________\n')
print('Axial Forces (+ve: tension, -ve: Compression)')
print('_______________________________________________\n')
axial=pd.DataFrame({'Member': data.bars_SN,
                    'Axial force': np.array(ax)}).set_index(['Member'])
print(axial)
print('_______________________________________________\n')
print('Reaction Forces (+ve: Upward, -ve: Downward)')
print('_______________________________________________\n')
print(Rxn)
print('_______________________________________________\n')
print('Deformation at nodes')
print('_______________________________________________\n')

defln=pd.DataFrame(U, columns =['\u0394x', '\u0394y'])
print(defln)

Plot(nodes,'gray','--',1,'Undeformed')
scale=1
Dnodes=U*scale+nodes
Plot(Dnodes,'k','-',3,'Deformed')

    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    





